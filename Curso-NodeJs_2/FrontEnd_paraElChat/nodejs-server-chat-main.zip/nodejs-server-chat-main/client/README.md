# Client

## Instructions

- Install the dependencies and then run the client.

```
npm install
npm start
```
